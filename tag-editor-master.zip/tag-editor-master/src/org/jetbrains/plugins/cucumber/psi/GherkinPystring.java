package org.jetbrains.plugins.cucumber.psi;

public interface GherkinPystring extends GherkinPsiElement {
}
