package org.jetbrains.plugins.cucumber.psi;

import com.intellij.psi.PsiElement;

/**
 * @author yole
 */
public interface GherkinPsiElement extends PsiElement {
}
