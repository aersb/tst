# tag-editor

Tihs is a Plugin for IntelliJ Idea to support PageFactory-2

The plugin can be downloaded [here](https://plugins.jetbrains.com/plugin/13227-test-automation-gears/)
