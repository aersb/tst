package org.jetbrains.plugins.cucumber.psi;

import com.intellij.psi.PsiNameIdentifierOwner;

public interface GherkinTableCell extends GherkinPsiElement, PsiNameIdentifierOwner {
}
