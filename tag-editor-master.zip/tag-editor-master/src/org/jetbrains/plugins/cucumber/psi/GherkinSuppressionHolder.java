package org.jetbrains.plugins.cucumber.psi;

import com.intellij.psi.PsiElement;

/**
 * @author Roman.Chernyatchik
 * @date Aug 13, 2009
 */
public interface GherkinSuppressionHolder extends PsiElement{
}
